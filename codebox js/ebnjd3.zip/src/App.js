import {useFetch} from "./useFetch";
import "./App.css";

function App() {
  const{data, loading, error, handleCancelRequest} = useFetch(
    "https://jsonplaceholder.typicode.com/users"
  );

  return (
    <div className="App">
      <h1>Hello CodeSandbox</h1>
      <button onClick={handleCancelRequest}>Cancel Request</button>
      <div className="card">
        <ul>
          {error && <li>Error: {error}</li>}
          {loading && <li> Loading...</li>}
          {data?.map((user) =>(
            <li key={user.id}>{user.name}</li>
  ))}

// useState: este hook nos permite el cambiar o añadir un estado como por ejemplo 
un conteo
// useEffect: este hook nos perimte añadir elementos dentro de funciones o donde 
este activo el hook
// Fetch: este metodo nos permite hacer pedidos a servidores aparte de cargar
la informacion 
// no se porque me muestra los errores, pienso que es por el tipo de extension .js y que 
en el video era .jsx
