import "./styles.css";

import MainLayout from "Layouts/MainLayout";

export default function App() {
  return <MainLayout />;
}
