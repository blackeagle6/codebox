import {
  MenuFoldOutlined,
  MenuUnfoldOutlined,
  UserOutLined
} from "@ant-design/icons";
import { Button, Layout, Menu, Row, Col } from "antd";
import { Link, Outlet } from "react-router-dom";
import styled from "styled-components";
import { useState } from "react";

const { Header, Sider, Content, Footer } = Layout;

export default function MainLayout() {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <Layout>
      <Sider trigger={null} collapsible collapsed={collapsed}>
        <Menu
          theme="dark"
          mode="inline"
          items={[
            {
              key: "1",
              icon: <UserOutLined />,
              label: <Link to="/home"> Home </Link>
            },
            {
              key: "2",
              icon: <UserOutLined />,
              label: <Link to="about"> About </Link>
            },
            {
              key: "3",
              icon: <UserOutLined />,
              label: <Link to="/home"> Community </Link>
            }
          ]}
        />
      </Sider>
      <Layout>
        <Header>
          <Row type="flex" justify="space-between">
            <Col>
              <Button
                type="text"
                icon={collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
                onClick={() => setCollapsed(!collapsed)}
              />
            </Col>
          </Row>
        </Header>
        <Content>Content</Content>
        <Footer>Communitex</Footer>
      </Layout>
    </Layout>
  );
}
