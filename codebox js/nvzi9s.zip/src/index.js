import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App";
/*
RELATIVE PATH
import Component from "./../../../../../../../App.js"
ABSOLUTE PATH
import Componente from ./components/folder1/folder2/folder3/App.js

*/
const rootElement = document.getElementById("root");
const root = createRoot(rootElement);
root.render(
  <StrictMode>
    <BrowserRouter>
      {" "}
      <App />
    </BrowserRouter>
  </StrictMode>
);
